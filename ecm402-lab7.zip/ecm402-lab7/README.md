
# ECM-402 AI for Signal Processing — Lab 7

## Title
Independent Component Analysis, Dimensionality Reduction
and Unsupervised Learning

## Objective
The objective of this laboratory assignment is to study
ICA, PCA and unsupervised clustering algorithms for
signal processing applications.

## Experiments

1. Independent Component Analysis (ICA)
2. Comparison of ICA and PCA
3. Gaussian source identifiability
4. PCA dimensionality reduction
5. K-Means clustering
6. Gaussian Mixture Model (GMM)
7. Agglomerative clustering
8. Spectral clustering
9. Clustering performance under different SNR levels

## Algorithms Used

- FastICA
- Principal Component Analysis (PCA)
- K-Means
- Gaussian Mixture Model
- Agglomerative Clustering
- Spectral Clustering

## Dataset
Synthetic independent source signals, digital modulation
signals (BPSK, QPSK, 8PSK and 16QAM), and two-moons
nonlinear clustering dataset.

## Results
- ICA successfully separates mixed source signals.
- PCA reduces dimensionality while retaining most variance.
- K-Means, GMM and Agglomerative clustering are evaluated.
- Spectral clustering handles nonlinear two-moons data.
- SNR experiments demonstrate the effect of noise on clustering.

## Installation

Install the required libraries:

    pip install -r requirements.txt

## Execution

Run the experiment notebook or execute the Python source
file after setting up the required dependencies.

## Reproducibility
Random seed: 0

## Folder Structure

    ecm402-lab7/
    ├── README.md
    ├── requirements.txt
    ├── report.pdf
    ├── src/
    └── results/
        ├── figures/
        └── tables/
